# geoprovenance

A package ingesting and tracking geospatial data and its provenance.

## Installation

```bash
pip install geoprovenance@git+https://github.com/davidyshen/geo_provenance
```

## Usage

```python
# Add usage examples here
```

## License

`geoprovenance` was created by David Shen. It is licensed under the terms of the MIT license.
